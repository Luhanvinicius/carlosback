-- AlterTable
ALTER TABLE "Atleta" ADD COLUMN     "fone" TEXT;

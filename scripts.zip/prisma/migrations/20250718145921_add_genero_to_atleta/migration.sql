-- AlterTable
ALTER TABLE "Atleta" ADD COLUMN     "genero" TEXT;
